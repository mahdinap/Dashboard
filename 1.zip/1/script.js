const switchBtn=document.querySelector(".toggle-switch")
const toggle=document.querySelector(".toggle")
const sidebar=document.querySelector(".sidebar")
const body=document.querySelector("body")

switchBtn.addEventListener("click",()=>{
    body.classList.toggle("dark")    
})

toggle.addEventListener("click",()=>{
    sidebar.classList.toggle("close")    
})